export default (async () => {
  const { readdir, readFile, stat } = await import("fs/promises");
  const { join } = await import("path");

  return {
    "experimental.chat.system.transform": async (_input, output) => {
      try {
        const logDir = join(process.cwd(), "logs");

        let files;
        try {
          files = await readdir(logDir);
        } catch {
          return;
        }

        const mdFiles = files.filter(f => f.endsWith(".md"));
        if (mdFiles.length === 0) return;

        const withStats = await Promise.all(
          mdFiles.map(async (name) => {
            const p = join(logDir, name);
            const s = await stat(p);
            return { name: p, mtime: s.mtimeMs };
          })
        );

        withStats.sort((a, b) => b.mtime - a.mtime);
        const content = await readFile(withStats[0].name, "utf-8");

        output.system.push("\n\n[Previous conversation context]:\n" + content);
      } catch (e) {
        console.error("Auto-inject error:", e);
      }
    },
  };
});
