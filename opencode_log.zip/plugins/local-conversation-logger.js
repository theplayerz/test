export default (async () => {
  const { mkdir, appendFile } = await import("fs/promises");
  const { join } = await import("path");

  let lastUserText = "";
  let projectCwd = null;
  const msgRoles = new Map();
  const assistantTexts = new Map();

  return {
    event: async (input) => {
      try {
        const e = input.event;

        if (e.type === "message.updated") {
          const info = e.properties?.info;
          if (info?.role) {
            msgRoles.set(info.id, info.role);
            if (info.role === "assistant" && info.path?.cwd) {
              projectCwd = info.path.cwd;
            }
          }
        }

        if (e.type === "message.part.updated") {
          const part = e.properties.part;
          const messageID = part?.messageID;
          const role = msgRoles.get(messageID);

          if (role === "user" && part.type === "text" && part.text) {
            lastUserText = part.text;
          }

          if (role === "assistant" && part.type === "text" && part.text) {
            assistantTexts.set(messageID, part.text);
          }

          // step-finish → assistant response done
          if (part?.type === "step-finish") {
            await new Promise((r) => setTimeout(r, 200));

            const text = (assistantTexts.get(messageID) || "").trim();
            const cwd = projectCwd || process.cwd();

            if (lastUserText && text) {
              const now = new Date();
              const y = now.getFullYear();
              const mo = String(now.getMonth() + 1).padStart(2, "0");
              const d = String(now.getDate()).padStart(2, "0");
              const hh = String(now.getHours()).padStart(2, "0");
              const mm = String(now.getMinutes()).padStart(2, "0");
              const ss = String(now.getSeconds()).padStart(2, "0");

              const q = lastUserText.replace(/\n/g, " ").slice(0, 300);
              const a = text.replace(/\n/g, " ").slice(0, 500);
              const dir = join(cwd, "logs");
              await mkdir(dir, { recursive: true });
              const entry = `\n## [${hh}:${mm}:${ss}]\n**Q:** ${q}\n**A:** ${a}\n---\n`;
              await appendFile(join(dir, `${y}-${mo}-${d}.md`), entry, "utf-8");
            }

            assistantTexts.delete(messageID);
            lastUserText = "";
          }
        }
      } catch (e) {
        console.error("Logger plugin error:", e);
      }
    },
  };
});
